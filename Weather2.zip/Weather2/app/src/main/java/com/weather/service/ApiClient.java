package com.weather.service;

/**
 * Created by meaad on 9/19/17.
 */

public class ApiClient {
    public static String KEY ="0dfd524993bce9d79629ac93e3ed1c15";
    public static String BASEURL = "http://api.openweathermap.org/data/2.5/";
}
