package com.weather;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.weather.model.WeatherResponse;
import com.weather.service.ApiClient;
import com.weather.service.ApiInterface;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {
    @BindView(R.id.date)
    TextView date;
    @BindView(R.id.city) TextView city;
    @BindView(R.id.temp) TextView temp;

    @BindView(R.id.descrip) TextView descrip;
    @BindView(R.id.image)
    ImageView image;

    public static final String WEATHER_TYPE_CLOUDS = "Clouds";
    public static final String WEATHER_TYPE_CLEAR = "Clear";
    public static final String WEATHER_TYPE_RAIN = "Rain";
    public static final String WEATHER_TYPE_WIND = "Wind";
    public static final String WEATHER_TYPE_SNOW =  "Snow";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        ButterKnife.bind(this);
//create retrofit instance
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(ApiClient.BASEURL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        //create interface instance
        ApiInterface service = retrofit.create(ApiInterface.class);
        Call<WeatherResponse> call = service.getweather("London",ApiClient.KEY);
call.enqueue(new Callback<WeatherResponse>() {
    @Override
    public void onResponse(Call<WeatherResponse> call, Response<WeatherResponse> response) {
        //success access
        if (response.code()== 200 ){

            date.setText("Today , Sep 19");
                    descrip.setText(response.body().getWeather().get(0).getDescription());
            city.setText(response.body().getName());


double d=response.body().getMain().getTemp();
            int tmp= (int)d;
temp.setText(tmp+"");

            switch (response.body().getWeather().get(0).getMain()) {
                case WEATHER_TYPE_CLEAR:
                    image.setImageDrawable(getResources().getDrawable(R.drawable.sunny_mini));
                    break;
                case WEATHER_TYPE_CLOUDS:
                    image.setImageDrawable(getResources().getDrawable(R.drawable.cloudy_mini));
                    break;
                case WEATHER_TYPE_RAIN:
                    image.setImageDrawable(getResources().getDrawable(R.drawable.rainy_mini));;
                    break;
                default:
                    image.setImageDrawable(getResources().getDrawable(R.drawable.sunny_mini));}


                    Toast.makeText(MainActivity.this, "Success", Toast.LENGTH_SHORT).show();

        }
        else {
            Toast.makeText(MainActivity.this, "Invalid token", Toast.LENGTH_SHORT).show();

        }
        // token invalid
    }

    @Override
    public void onFailure(Call<WeatherResponse> call, Throwable t) {
// error net work connection
        Toast.makeText(MainActivity.this, "Error can't make connection", Toast.LENGTH_SHORT).show();
    }
});
    }


}
