package com.weather.service;

import com.weather.model.WeatherResponse;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

/**
 * Created by meaad on 9/19/17.
 */

public interface ApiInterface {

    @GET("weather")
    Call<WeatherResponse> getweather(@Query("q") String city , @Query("appid") String appied);
}
